import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './HistorialClinico.css';
import HistorialClinicoService from '../services/HistorialClinicoService';
import Header from './Header'
import PacienteService from '../services/PacienteService'
function HistorialClinico() {
  const [tratamientos, setTratamientos] = useState([]);
  const [, setNumeroPieza] = useState(null);
  const [numeroDienteSeleccionado, setNumeroDienteSeleccionado] = useState(null);
  const [, setNumeroPiezaSeleccionada] = useState(null);
  const { numeroDiente } = useParams();
  const { dni,  } = useParams('');
  const [nombrePaciente, setNombrePaciente] = useState('');
  const [apellidoPaciente, setApellidoPaciente] = useState('');
  const navigate = useNavigate();


  useEffect(() => {
    setNumeroPieza(numeroDiente);

  }, [numeroDiente]);

  useEffect(() => {
    HistorialClinicoService.getHistorialClinicoByPacienteDNI(dni).then((res) => {
      setTratamientos(res.data);
      console.log(dni)
    });
    PacienteService.getPacienteByDni(dni).then((res) => {
      setNombrePaciente(res.data.nombre);
      setApellidoPaciente(res.data.apellido);
      console.log(res.data.nombre)
    })
    
  }, [dni]);

  

  const handleMostrarCuadroTratamiento = (numero) => {
    setNumeroDienteSeleccionado(numero);
    setNumeroPiezaSeleccionada(numero);
    navigate(`/`, { state: { selectedPiezaId: numero } });
  };

  const agregarTratamiento = (dniParam) => {
    navigate(`/agregar-historial/${dniParam}`);
  };

  const deleteTratamiento = (tratamientoId) => {
    HistorialClinicoService.deleteHistorialClinico(tratamientoId).then((res) => {
      setTratamientos((prevTratamientos) => prevTratamientos.filter((tratamiento) => tratamiento.id !== tratamientoId));
    }).catch(error => {
      console.error("Error al eliminar el tratamiento:", error);
    });
  };

  const rutasDientes = [
    { ruta:'/dentadura-sup-18.png',numero:'18'},
    {ruta:'/dentadura-sup-17.png',numero:'17'},
    {ruta:'/dentadura-sup-16.png',numero:'16'},
    {ruta:'/dentadura-sup-15.png',numero:'15'},
    {ruta:'/dentadura-sup-14.png',numero:'14'},
    {ruta:'/dentadura-sup-13.png',numero:'13'},
    {ruta:'/dentadura-sup-12.png',numero:'12'},
    {ruta:'/dentadura-sup-11.png',numero:'11'},
    {ruta:'/dentadura-sup-21.png',numero:'21'},
    {ruta:'/dentadura-sup-22.png',numero:'22'},
    {ruta:'/dentadura-sup-23.png',numero:'23'},
    {ruta:'/dentadura-sup-24.png',numero:'24'},
    {ruta:'/dentadura-sup-25.png',numero:'25'},
    {ruta:'/dentadura-sup-26.png',numero:'26'},
    {ruta:'/dentadura-sup-27.png',numero:'27'},
    {ruta:'/dentadura-sup-28.png',numero:'28'},
    {ruta:'/dentadura-inf-48.png',numero:'48'},
    {ruta:'/dentadura-inf-47.png',numero:'47'},
    {ruta:'/dentadura-inf-46.png',numero:'46'},
    {ruta:'/dentadura-inf-45.png',numero:'45'},
    {ruta:'/dentadura-inf-44.png',numero:'44'},
    {ruta:'/dentadura-inf-43.png',numero:'43'},
    {ruta:'/dentadura-inf-42.png',numero:'42'},
    {ruta:'/dentadura-inf-41.png',numero:'41'},
    {ruta:'/dentadura-inf-31.png',numero:'31'},
    {ruta:'/dentadura-inf-32.png',numero:'32'},
    {ruta:'/dentadura-inf-33.png',numero:'33'},
    {ruta:'/dentadura-inf-34.png',numero:'34'},
    {ruta:'/dentadura-inf-35.png',numero:'35'},
    {ruta:'/dentadura-inf-36.png',numero:'36'},
    {ruta:'/dentadura-inf-37.png',numero:'37'},
    {ruta:'/dentadura-inf-38.png',numero:'38'},
  ];

  const primeraFila = rutasDientes.slice(0, 16);
  const segundaFila = rutasDientes.slice(16);

  return (
    <div>
      <Header />
      <div className="container_1">
        <h2 className="titulo_diente">Paciente: {nombrePaciente} {apellidoPaciente}</h2>
        <h2 className="titulo_diente">Ficha Médica</h2>
        <div className="odontograma">
          <div className="fila">
            {primeraFila.map((imagen) => (
              <div className={`imagen-container ${numeroDienteSeleccionado === imagen.numero ? 'seleccionado' : ''}`} key={imagen.numero}>
                <img
                  src={process.env.PUBLIC_URL + imagen.ruta}
                  alt="Diente"
                  className="imagenes"
                  onClick={() => handleMostrarCuadroTratamiento(imagen.numero)}
                />
                <div className="numero">{imagen.numero}</div>
              </div>
            ))}
            <div className="linea-vertical"></div>
            <div className="linea-vertical"></div>
            <div className="linea-vertical"></div>
          </div>
          <hr className="linea-horizontal" />
          <hr className="linea-horizontal" />

          <div className="fila">
            {segundaFila.map((imagen, index) => (
              <div className={`imagen-container ${numeroDienteSeleccionado === imagen.numero ? 'seleccionado' : ''}`} key={index}>
                <img
                  src={process.env.PUBLIC_URL + imagen.ruta}
                  alt="Diente"
                  className="imagen"
                  onClick={() => handleMostrarCuadroTratamiento(imagen.numero)}
                />
                <div className="numero fila-inferior">{imagen.numero}</div>
              </div>
            ))}
          </div>
        </div>
        <div className='container-fluid' style={{ marginLeft: "10px" }}>
          <h2>Registro de Tratamiento</h2>
          <button onClick={() => agregarTratamiento(dni)} className='btn btn-info'>Agregar</button>
          <div className="row"></div>
          <table className="table table-striped table-bordered" >
            <thead>
              <tr>
                <th>Fecha de consulta</th>
                <th>Tratamiento</th>
                <th>Cara</th>
                <th>Pieza</th>
                <th>Descripcion</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {tratamientos.map((tratamiento) => (
                <tr key={tratamiento.id}>
                  <td>{tratamiento.fecha || ''}</td>
                  <td>{tratamiento.tratamiento || ''}</td>
                  <td>{tratamiento.cara}</td>
                  <td>{tratamiento.pieza}</td>
                  <td>{tratamiento.descripcion}</td>
                  <td style={{ textAlign: 'center' }}>
                  <button onClick={() => tratamiento.id && deleteTratamiento(tratamiento.id)} className='btn btn-danger' style={{ marginLeft: "10px" }}>Eliminar</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
export default HistorialClinico;