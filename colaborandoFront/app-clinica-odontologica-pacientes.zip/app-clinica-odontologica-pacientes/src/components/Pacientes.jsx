import React, { useState, useEffect } from 'react';
import Header from './Header';
import PacienteService from '../services/PacienteService';
import { useNavigate } from 'react-router-dom';

function Paciente() {
  const [busqueda, setBusqueda] = useState('');
  const [pacientes, setPacientes] = useState([]);
  const [paginaActual, setPaginaActual] = useState(1);
  const tamanoPagina = 10;
  const ultimaPagina = paginaActual * tamanoPagina;
  const primeraPagina = ultimaPagina - tamanoPagina;
  const navigate = useNavigate();
  const tamanos = pacientes.slice(primeraPagina, ultimaPagina);
  const npaginas = Math.ceil(pacientes.length / tamanoPagina)
  const numeros = [...Array(npaginas + 1).keys()].slice(1)
  const rol = localStorage.getItem("rol");


  useEffect(() => {
    if (busqueda && busqueda.length > 0) {
      PacienteService.buscarPacientesPorNombre(busqueda)
        .then(resultados => {
          setPacientes(resultados);

        })
        .catch(error => {
          console.error('Error en la búsqueda:', error);
        });
    } else {
      PacienteService.getPaciente()
        .then((res) => {
          setPacientes(res.data);
        })
        .catch(error => {
          console.error('Error al cargar pacientes:', error);
        });
    }
  }, [busqueda]);

  const addPaciente = () => {
    navigate('/crear-paciente');
  }

  const editPaciente = (dni) => {
    navigate(`/actualizar-paciente/${dni}`);
  }

  const deletePaciente = (dni) => {
    PacienteService.deletePaciente(dni).then((res) => {
      setPacientes((prevPacientes) => prevPacientes.filter((paciente) => paciente.dni !== dni));
    });
  };

  const historialClinico = (dni) => {
    navigate(`/historial-clinico/${dni}`);
  }

  const handleBusquedaChange = (e) => {
    setBusqueda(e.target.value);
  };

  return (
    <div >
      <Header />
      <form action="" className='form-inline'>
        <div className="busqueda d-flex justify-content-center align-items-center" style={{ margin: "15px" }}>
          <input
            id="input"
            type="text"
            autoComplete="off"
            className='form-control d-flex justify-content-center align-items-center'
            spellCheck="false"
            role="combobox"
            aria-controls="matches"
            placeholder="Buscar por nombre, DNI o apellido"
            aria-expanded="false"
            aria-live="polite"
            value={busqueda}
            onChange={handleBusquedaChange}
          />
          <input type="submit" className='btn btn-primary mb-2' value="Buscar" />
        </div>
        <div className='container-fluid' style={{ marginLeft: "10px" }}>
          <h2 className='text-center'>Lista de Pacientes</h2>
          <div className='row'>
            <button className='btn btn-primary' onClick={addPaciente} style={{ marginBottom: "10px" }} >Agregar Paciente</button>
          </div>
          <div className="row">
            <table className="table table-striped table-bordered">
              <thead>
                <tr>
                  <th>DNI</th>
                  <th>Nombre</th>
                  <th>Apellido</th>
                  <th>Correo</th>
                  <th>Teléfono</th>
                  <th>Alergias</th>
                  <th>Tratamiento</th>
                  <th>Opciones</th>
                </tr>
              </thead>
              <tbody>
                {tamanos.map(paciente => (
                  <tr key={paciente.id}>
                    <td>{paciente.dni}</td>
                    <td>{paciente.nombre}</td>
                    <td>{paciente.apellido}</td>
                    <td>{paciente.email}</td>
                    <td>{paciente.telefono}</td>
                    <td>{paciente.alergias}</td>
                    <td>{paciente.tratamiento}</td>
                    <td style={{ textAlign: 'center' }}>
                      <button onClick={() => editPaciente(paciente.dni)} className='btn btn-info'>Actualizar</button>
                      {
                        rol ==="ODONTOLOGO" ?                       
                          <button onClick={() => historialClinico(paciente.dni)} className='btn btn-success' style={{ marginLeft: "10px" }}>Historial</button>
                          : null
                      }
                      <button onClick={() => deletePaciente(paciente.dni)} className='btn btn-danger' style={{ marginLeft: "10px" }}>Eliminar</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <nav>
              <ul className='pagination'>
                <li className='page-item'>
                  <button href="#" className='page-link' onClick={(e) => prePagina(e)}>Prev</button>
                </li>
                {
                  numeros.map((n, id) => (
                    <li className={`page-item ${paginaActual === n ? 'active' : ''}`} key={id}>
                      <button href="#" className='page-link' onClick={(e) => changeCPage(e, n)}>
                        {n}
                      </button>
                    </li>
                  ))
                }
                <li className='page-item'>
                  <button href="" className='page-link' onClick={(e) => siguientePagina(e)}>Siguiente</button>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </form>
    </div>
  );

  function prePagina() {
    if (paginaActual !== 1) {
      setPaginaActual(paginaActual - 1)
    }
  }

  function changeCPage(e, id) {
    e.preventDefault();
    setPaginaActual(id);
  }

  function siguientePagina() {
    if (paginaActual !== npaginas) {
      setPaginaActual(paginaActual + 1)
    }
  }
}

export default Paciente;
