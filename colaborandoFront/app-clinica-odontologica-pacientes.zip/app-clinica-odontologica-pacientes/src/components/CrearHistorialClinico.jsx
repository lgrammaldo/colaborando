
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, useParams } from 'react-router-dom';
import OdontologoService from '../services/OdontologoService';
import PacienteService from '../services/PacienteService';
import HistorialClinicoService from '../services/HistorialClinicoService';
import Header from './Header';

const CrearHistorialClinico = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [pieza, setPieza] = useState(location?.state?.selectedPiezaId || '');
  const [lesiones, setLesiones] = useState('');
  const [odontologoId, setOdontologoId] = useState('');
  const [fecha, setFecha] = useState('');
  const [tratamiento, setTratamiento] = useState('');
  const [cara, setCara] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [pacientes, setPacientes] = useState([]);
  const [odontologos, setOdontologos] = useState([]);
  const [error, setError] = useState('');
  const { dni, setDNI } = useParams('');

  useEffect(() => {
    PacienteService.getPaciente()
      .then((res) => {
        setPacientes(res.data);
      })
      .catch((error) => {
      });

    OdontologoService.getOdontologo()
      .then((res) => {
        setOdontologos(res.data);
      })
      .catch((error) => {
      });
console.log(dni)

    // Asignar el número recuperado de la URL
  }, [dni]);


  const saveTratamiento = async (e) => {
    e.preventDefault();
    // Verifica que el DNI del paciente esté presente
  if (!dni) {
    setError('El DNI del paciente no está disponible.');
    return;
  }

  // Verifica si los datos de los pacientes están disponibles
  if (!pacientes || pacientes.length === 0) {
    // Si los datos de los pacientes no están disponibles, espera un momento y vuelve a intentarlo
    setTimeout(() => {
      const pacienteSeleccionado = pacientes.find(paciente => paciente.dni.toString() === dni.toString());
      if (!pacienteSeleccionado) {
        setError('No se encontró al paciente correspondiente.');
      } else {
        // Limpia el mensaje de error si no hay errores
        setError('');
        // Continúa con la lógica para guardar el tratamiento aquí
      }
    }, 1000); // Espera 1 segundo antes de volver a intentarlo
    return;
  }

  // Encuentra al paciente correspondiente en la lista de pacientes
  const pacienteSeleccionado = pacientes.find(paciente => paciente.dni.toString() === dni.toString());

  // Verifica que se haya encontrado el paciente
  if (!pacienteSeleccionado) {
    setError('No se encontró al paciente correspondiente.');
    return;
  }

  // Limpia el mensaje de error si no hay errores
  setError('');

  // Construye el nuevo tratamiento con el paciente asociado
  const idP= pacienteSeleccionado.id + ""
  const nuevoTratamiento = {
    
    paciente: { id: idP}, 
      odontologo: { id: odontologoId },
      fecha,
      tratamiento,
      cara,
      pieza,
      descripcion,
      lesiones,
    };

    HistorialClinicoService.createHistorialClinico(nuevoTratamiento)
      .then(res => {
        navigate(`/historial-clinico/${dni}`);
        console.log("Turno:", nuevoTratamiento);
                alert("El tratamiento se ha creado correctamente.");
      })
      .catch(error => {
        alert("Hubo un error al crear el tratamiento. Por favor, inténtalo de nuevo.");
      });
  }
  const cancelTratamiento = () => {
    navigate('/tratamientos');
  };

  return (
    <div>
      <Header />
      <div className='row mt-4'>
        <div className='card col-md-6 offset-md-3 offset-md-3'>
          <h2 className="text-center">Diagnostico</h2>
          <div className="card-body">
            <form>
              <div className='form-group'>
                <label>Odontólogo: </label>
                <select name="odontologo" className='form-control' value={odontologoId} onChange={(e) => setOdontologoId(e.target.value)}>
                  <option value="">Seleccionar Odontólogo</option>
                  {odontologos.map((odontologo) => (
                    <option key={odontologo.id} value={odontologo.id}>{odontologo.nombre} {odontologo.apellido}</option>
                  ))}
                </select>
              </div>
              <div className='form-group'>
                <label>Fecha:</label>
                <input type="date" name="paciente" className='form-control' value={fecha} onChange={(e) => setFecha(e.target.value)}></input>
              </div>
              <div className='form-group'>

                <label>Pieza:</label>
                <select value={pieza} onChange={(e) => setPieza(e.target.value)} className='form-control'>
                  <option value="" disabled>Seleccionar pieza</option>
                  {Array.from({ length: 8 }, (_, index) => index + 1).map(decade =>
                    <optgroup label={decade * 10} key={decade}>
                      {Array.from({ length: 8 }, (_, index) => decade * 10 + index + 1).map(option => (
                        <option key={option} value={option}>{option}</option>
                      ))}
                    </optgroup>
                  )}
                </select>
              </div>
              <label>Cara:</label>
              <select name="cara" className='form-control' value={cara} onChange={(e) => setCara(e.target.value)}>
                <option value="">Seleccionar cara</option>
                {['Vestibular', 'Lingual', 'Palatino', 'Mesial', 'Distal', 'Oclusal'].map(option => (
                  <option key={option} value={option}>{option}</option>
                ))}
              </select>
              <label>Tratamiento:</label>
              <select name="tratamiento" className='form-control' value={tratamiento} onChange={(e) => setTratamiento(e.target.value)}>
                <option value="">Seleccionar tratamiento</option>
                <option value="apiceptomias">Apiceptomía</option>
                <option value="carillas">Carillas</option>
                <option value="cirugia">Cirugía</option>
                <option value="contanto-alimento">Contanto Alimento</option>
                <option value="corona">Corona</option>
                <option value="corona-provisora">Corona provisoria</option>
                <option value="restauracion">restauracion</option>
                <option value="implante">Implante</option>
                <option value="corona">Corona</option>
                <option value="corona-mal">Corona Mal Estado</option>
                <option value="protesis">Protesis Removible</option>
                <option value="curetajes">Curetaje</option>
                <option value="endodoncia">Endodoncia</option>
                <option value="esqueletico">Esquelético</option>
                <option value="estetica">Estética</option>
                <option value="exploracion">Exploración</option>
                <option value="extrusion">Extrusión</option>
                <option value="furcas">Furcas</option>
                <option value="">Girar</option>
                <option value="otro">otro</option>
              </select>
              <label>Lesiones:</label>
              <select
                name="lesiones"
                className="form-control"
                value={lesiones}
                onChange={(e) => setLesiones(e.target.value)}
              >
                <option value="">Seleccionar lesión</option>
                <option value="caries">Caries</option>
                <option value="infeccion-pulpal">Infección pulpal</option>
                <option value="fractura">Fractura</option>
                <option value="movilidad">Movilidad</option>
                <option value="Residuo-radicular">Residuo Radicular</option>
                <option value="erosion">Erosion</option>
                <option value="atricion">Atricion</option>
                <option value="abfraccion">Abfraccion</option>
                <option value="sin-erupcionar">Sin erupcionar</option>
                <option value="diente-sano">Diente Sano</option>
                <option value="otro">Otro</option>
              </select>
              <div className='form-group'>
                <label>Observaciones:</label>
                <textarea name="descripcion" className='descripcion-textarea' style={{ width: '100%' }} value={descripcion} onChange={(e) => setDescripcion(e.target.value)}></textarea>
              </div>
              {error && <div className="alert alert-danger" role="alert">{error}</div>}
              <button className='btn btn-success' onClick={(e) => saveTratamiento(e)}> Guardar </button>
              <button className='btn btn-danger' onClick={cancelTratamiento} style={{ marginLeft: "10px" }}>Cancelar</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CrearHistorialClinico;