import React, { useState, useEffect } from 'react';
import pacienteService from '../services/PacienteService';
import { useNavigate, useParams } from 'react-router-dom';
import tratamientoService from '../services/TratamientoService';
import Header from './Header';

const ActualizarPaciente = () => {
    const [nombre, setNombre] = useState('');
    const [apellido, setApellido] = useState('');
    const [email, setEmail] = useState('');
    const [telefono, setTelefono] = useState('');
    const {dni, setDNI} = useParams('');
    const [alergias, setAlergias] = useState('');
    const [tratamiento, setTratamiento] = useState('');
    const [tratamientosDisponibles, setTratamientosDisponibles] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        // Aquí obtén las especialidades desde tu servicio y guárdalas en el estado
        tratamientoService.getTratamiento().then((res) => {
            console.log(res.data)
            setTratamientosDisponibles(res.data);
        }).catch((error) => {
            // Maneja los errores si es necesario
        });
    }, []);

    useEffect(() => {
        pacienteService.getPacienteByDni(dni).then((res) => {
            const paciente = res.data;
            setNombre(paciente.nombre);
            setApellido(paciente.apellido);
            setEmail(paciente.email);
            setTelefono(paciente.telefono);
            setAlergias(paciente.alergias);
            setTratamiento(paciente.tratamiento)
            if (paciente.tratamientosDisponibles) {
                setTratamientosDisponibles(paciente.tratamientosDisponibles);
            }
        });
    }, [dni]);

    const savePaciente = (e) => {
        e.preventDefault();
        const paciente = {
            nombre,
            apellido,
            email,
            telefono,
            dni,
            alergias,
            tratamiento
        };

        console.log("paciente => " + JSON.stringify(paciente));
        pacienteService.updatePaciente(dni, paciente)
            .then(res => {
                navigate('/paciente');
                alert("El paciente se ha actualizado correctamente.");

            })
            .catch(error => {
                alert("Hubo un error al actualizar el turno. Por favor, inténtalo de nuevo.");
            });
    }

    const cancelPaciente = () => {
        navigate('/paciente');
    }

    return (
        <div>
            <Header />
            <div className='row'>
                <div className='card col-md-6 offset-md-3 offset-md-3'>
                    <h2 className="text-center">Editar Paciente</h2>
                    <div className="card-body">
                        <form>
                            <div className='form-group'>
                                <label>Nombre: </label>
                                <input type="text" name="nombre" className='from-control' value={nombre} onChange={(e) => setNombre(e.target.value)} />
                            </div>
                            <div className='form-group'>
                                <label>Apellido: </label>
                                <input type="text" name="nombre" className='from-control' value={apellido} onChange={(e) => setApellido(e.target.value)} />
                            </div>
                            <div className='form-group'>
                                <label>DNI: </label>
                                <input type="text" name="dni" className='from-control' value={dni} onChange={(e) => setDNI(e.target.value)} />
                            </div>
                            <div className='form-group'>
                                <label>Correo: </label>
                                <input type="text" name="email" className='from-control' value={email} onChange={(e) => setEmail(e.target.value)} />
                            </div>
                            <div className='form-group'>
                                <label>Teléfono/Celular: </label>
                                <input type="text" name="telefono" className='from-control' value={telefono} onChange={(e) => setTelefono(e.target.value)} />
                            </div>
                            <div className='form-group'>
                                <label>Tratamiento: </label>
                                <select name="tratamiento" className='form-control' value={tratamiento} onChange={(e) => setTratamiento(e.target.value)}>
                                    <option value=""></option>
                                    {tratamientosDisponibles.map((esp, index) => (
                                        <option key={index} value={esp}>{esp}</option>
                                    ))}
                                </select>
                            </div>
                            <div className='form-group'>
                                <label>Alergias o indicaciones: </label>
                                <input type="text" name="alergias" className='from-control' value={alergias} onChange={(e) => setAlergias(e.target.value)} />
                            </div>

                            <button className='btn btn-success' onClick={savePaciente}>Guardar</button>
                            <button className='btn btn-danger' onClick={cancelPaciente} style={{ marginLeft: "10px" }}>Cancelar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ActualizarPaciente;
