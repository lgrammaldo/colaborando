import React, { Component } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'; // Importa Font Awesome
import { faTrash } from '@fortawesome/free-solid-svg-icons'; // Importa el ícono de borrado
import './HistorialClinico.css';
import Header from './Header';

class HistorialClinico extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedImages: new Set(),
      dienteSeleccionado: null,
      showModal: false,
      medico: "", // Agrega medico al estado
      fichaClinica: "", // Agrega fichaClinica al estado
      tratamientoSeleccionado: null,
      caraSeleccionada: null,
      selectedPiezaId: '', // Agrega selectedPiezaId al estado

      datosIngresados: [],
    };
  }

  handleMostrarModal = () => {
    this.setState({ showModal: true });
  }

  handleOcultarModal = () => {
    this.setState({ showModal: false });
  }


  handleTratamientoChange = (event) => {
    this.setState({ tratamientoSeleccionado: event.target.value });
  }

  handleCaraChange = (event) => {
    this.setState({ caraSeleccionada: event.target.value });
  }

  handleAñadirTratamiento = () => {
    // Crea un nuevo dato con medico y fichaClinica
    const nuevoDato = {
      diente: this.state.dienteSeleccionado,
      tratamiento: this.state.tratamientoSeleccionado,
      cara: this.state.caraSeleccionada,
      pieza: this.state.selectedPiezaId, // Agrega el valor de la pieza dental

      medico: this.state.medico, // Asigna el valor de medico del estado
      fichaClinica: this.state.fichaClinica, // Agrega fichaClinica al nuevoDato

    };

    this.setState((prevState) => ({
      datosIngresados: [...prevState.datosIngresados, nuevoDato],
    }));
    // Limpia los campos después de añadir el tratamiento
    this.setState({
      dienteSeleccionado: null,
      tratamientoSeleccionado: "",
      caraSeleccionada: "",
      medico: "", // Limpia el campo medico
      fichaClinica: "",

    });
    //  oculta la ventana de diálogo
    this.handleOcultarModal();
  }
  handleMedicoChange = (event) => {
    this.setState({ medico: event.target.value });
  }

  handleFichaClinicaChange = (event) => {
    this.setState({ fichaClinica: event.target.value });
  }
  handlePiezaDentalChange = (event) => {
    const selectedPiezaId = event.target.value;
    this.setState({
      selectedPiezaId: selectedPiezaId,
    });
  }
  handleMostrarCuadroTratamiento(index) {
    // Agrega lógica para deseleccionar la imagen si ya está seleccionada
    if (this.state.dienteSeleccionado === index) {
      this.setState({ dienteSeleccionado: null });
    } else {
      this.setState({ dienteSeleccionado: index });
      this.handleMostrarModal();
    }
  }
  handleImageClick(index) {
    const { selectedImages } = this.state;

    if (selectedImages.has(index)) {
      selectedImages.delete(index); // Si ya está seleccionado, se quíta
    } else {
      selectedImages.add(index); // Si no está seleccionado, se agrega
    }

    this.setState({ selectedImages: new Set(selectedImages) });
  }
  handleEliminarFila = (index) => {
    // Copia el array de datosIngresados eliminando el elemento en el índice proporcionado
    const nuevosDatosIngresados = [...this.state.datosIngresados];
    nuevosDatosIngresados.splice(index, 1);

    // Actualiza el estado con los nuevos datosIngresados sin el elemento eliminado
    this.setState({ datosIngresados: nuevosDatosIngresados });
  };

  render() {
    const rutasDientes = [
      { ruta: 'images/dentadura-sup-18.png', numero: '18' },
      { ruta: 'images/dentadura-sup-17.png', numero: '17' },
      { ruta: 'images/dentadura-sup-16.png', numero: '16' },
      { ruta: 'images/dentadura-sup-15.png', numero: '15' },
      { ruta: 'images/dentadura-sup-14.png', numero: '14' },
      { ruta: 'images/dentadura-sup-13.png', numero: '13' },
      { ruta: 'images/dentadura-sup-12.png', numero: '12' },
      { ruta: 'images/dentadura-sup-11.png', numero: '11' },
      { ruta: 'images/dentadura-sup-21.png', numero: '21' },
      { ruta: 'images/dentadura-sup-22.png', numero: '22' },
      { ruta: 'images/dentadura-sup-23.png', numero: '23' },
      { ruta: 'images/dentadura-sup-24.png', numero: '24' },
      { ruta: 'images/dentadura-sup-25.png', numero: '25' },
      { ruta: 'images/dentadura-sup-26.png', numero: '26' },
      { ruta: 'images/dentadura-sup-27.png', numero: '27' },
      { ruta: 'images/dentadura-sup-28.png', numero: '28' },
      { ruta: 'images/dentadura-inf-48.png', numero: '48' },
      { ruta: 'images/dentadura-inf-47.png', numero: '47' },
      { ruta: 'images/dentadura-inf-46.png', numero: '46' },
      { ruta: 'images/dentadura-inf-45.png', numero: '45' },
      { ruta: 'images/dentadura-inf-44.png', numero: '44' },
      { ruta: 'images/dentadura-inf-43.png', numero: '43' },
      { ruta: 'images/dentadura-inf-42.png', numero: '42' },
      { ruta: 'images/dentadura-inf-41.png', numero: '41' },
      { ruta: 'images/dentadura-inf-31.png', numero: '31' },
      { ruta: 'images/dentadura-inf-32.png', numero: '32' },
      { ruta: 'images/dentadura-inf-33.png', numero: '33' },
      { ruta: 'images/dentadura-inf-34.png', numero: '34' },
      { ruta: 'images/dentadura-inf-35.png', numero: '35' },
      { ruta: 'images/dentadura-inf-36.png', numero: '36' },
      { ruta: 'images/dentadura-inf-37.png', numero: '37' },
      { ruta: 'images/dentadura-inf-38.png', numero: '38' },
      // ... Tu lista de rutas de imágenes aquí ...
    ];

    const primeraFila = rutasDientes.slice(0, 16);
    const segundaFila = rutasDientes.slice(16);

    return (
      <div>
        <Header />
        <div className="container_1">
          <h2 className="titulo_diente">Registro dental</h2>
          <h2 className="titulo_diente">Ficha Médica</h2>

          <div className="odontograma">
            <div className="fila">


              {primeraFila.map((imagen, index) => (
                <div className={`imagen-container ${this.state.dienteSeleccionado === index ? 'imagen-seleccionada' : ''}`} key={index}>

                  <div className="image-and-number">

                    <img
                      src={imagen.ruta}
                      alt="Diente"
                      className={`imagen ${this.state.selectedImages[index] ? "seleccionado" : ""}`}
                      onClick={() => this.handleMostrarCuadroTratamiento(index)}
                    />
                    <div className="descripcion">{imagen.numero}</div>

                  </div>
                </div>
              ))}
              <div className="linea-vertical"></div>
              <div className="linea-vertical"></div>
              <div className="linea-vertical"></div>

            </div>
            <hr className="linea-horizontal" /> {/* Línea horizontal */}
            <hr className="linea-horizontal" /> {/* Línea horizontal */}
            <hr className="linea-horizontal" /> {/* Línea horizontal */}


            <div className="fila ">
              {segundaFila.map((imagen, index) => (
                <div className="imagen-container" key={index}>
                  <img
                    src={imagen.ruta}
                    alt="Diente"
                    className={`imagen ${this.state.selectedImages[index] ? "seleccionado" : ""}`}
                    onClick={() => this.handleMostrarCuadroTratamiento(index + 16)}
                  />
                  <div className="fila-inferior">{imagen.numero}</div>
                </div>
              ))}

            </div>
          </div>
          {this.state.showModal && (
            <div>
              <div className="dialogo-contenedor" ></div>
              <div className="dialogo">
                <span className="cerrar-modal" onClick={this.handleOcultarModal}>&times;</span>
                <h2 className="formulario-ventana">Añadir tratamiento</h2>
                <form>
                  <div>
                    <label>Medico:</label>
                    <input type="text"
                      id="medico"
                      name="medico"
                      placeholder="Nombre del médico"
                      value={this.state.medico}
                      onChange={this.handleMedicoChange}
                    />
                  </div>
                  <div>
                    <label>Ficha Clínica:</label>
                    <input type="text"
                      id="fichaClinica"
                      name="fichaClinica"
                      placeholder="Número de ficha clínica"
                      value={this.state.fichaClinica}
                      onChange={this.handleFichaClinicaChange}
                    />
                  </div>

                  <label>Seleccione pieza:</label>
                  <select className='horarios' onChange={this.handleTratamientoChange}>
                    <option value="11">11</option>
                    <option value="12">12</option>
                    <option value="13">13</option>
                    <option value="14">14</option>
                    <option value="15">15</option>
                    <option value="16">16</option>
                    <option value="17">17</option>
                    <option value="18">18</option>
                    <option value="21">21</option>
                    <option value="22">22</option>
                    <option value="23">23</option>
                    <option value="24">24</option>
                    <option value="25">25</option>
                    <option value="26">26</option>
                    <option value="27">27</option>
                    <option value="28">28</option>
                    <option value="31">31</option>
                    <option value="32">32</option>
                    <option value="33">33</option>
                    <option value="34">34</option>
                    <option value="35">35</option>
                    <option value="36">36</option>
                    <option value="37">37</option>
                    <option value="38">38</option>
                    <option value="41">41</option>
                    <option value="42">42</option>
                    <option value="43">43</option>
                    <option value="44">44</option>
                    <option value="45">45</option>
                    <option value="46">46</option>
                    <option value="47">47</option>
                    <option value="48">48</option>


                  </select>
                  <label>Seleccione Tratamiento:</label>
                  <select onChange={this.handleTratamientoChange} value={this.state.tratamientoSeleccionado}>

                    <option selected="" value="apiceptomias">Apiceptomía</option>
                    <option value="carillas.">Carillas</option>
                    <option value="cirugia">Cirugía</option>
                    <option value="icono-contacto-alimento.png">Contanto Alimento</option>
                    <option value="coronas.">Cororona</option>
                    <option value="curetajes">Curetaje</option>
                    <option value="endodoncias">Endodoncia</option>
                    <option value="esqueletico">Esquelético</option>
                    <option value="estetica">Estética</option>
                    <option value="exploración.">Exploración</option>
                    <option value="extrusion">Extrusión</option>
                    <option value="furcas">Furcas</option>
                    <option value="">Girar</option>
                    <option value="impacto-alimento">Impacto Alimento</option>
                    <option value="impresiones-estudio">Impresiones</option>
                    <option value="inclinación">Inclinación</option>
                    <option value="limpieza">Limpieza</option>
                    <option value="movilidad">Movilidad</option>
                    <option value="obturacion">Obturación</option>
                    <option value="ortodoncia">Ortodoncia</option>
                    <option value="perno.">Perno</option>
                    <option value="pilar">Pilar Solo</option>
                    <option value="transepitelial.">Pilar Transpitelial</option>
                    <option value="placa">Placa Descarga</option>
                    <option value="removible">Protesis Removible</option>
                    <option value="puente">Puente</option>
                    <option value="quitar">Quitar</option>
                    <option value="icono-radiografia.png">Radiografía</option>
                    <option value="icono-reconstrucción.png">Reconstrucción</option>
                    <option value="sangrado">Sangrado</option>
                    <option value="sellador">Sellador</option>
                    <option value="sensibilidad">Sensibilidad</option>
                    <option value="supurado">Supurado</option>
                    <option value="tornillo">Tornillo</option>
                    <option value="tornillo-solo">Tornillo Solo</option>
                    <option value="tratamiento.">Tratamiento</option>
                  </select>
                  <label>Seleccionar Cara:</label>
                  <select onChange={this.handleCaraChange} value={this.state.caraSeleccionada}>

                    <option selected="" value="Vestibular">Vestibular</option>
                    <option value="Lingual">Lingual</option>
                    <option value="Palatino">Palatino</option>
                    <option value="Mesial">Mesial</option>
                    <option value="Distal">Distal</option>
                    <option value="Oclusal">Oclusal</option>

                  </select>

                  <button onClick={this.handleAñadirTratamiento}>Añadir</button>
                </form>
              </div>
            </div>
          )}

          {/* Mostrar la tabla con los datos ingresados */}
          <div>
            <h2>Datos Ingresados</h2>
            <table>
              <thead>
                <tr>
                  <th>Medico</th>
                  <th>Ficha Clinica</th>
                  <th>Tratamiento</th>
                  <th>Cara</th>
                </tr>
              </thead>
              <tbody>
                {this.state.datosIngresados.map((dato, index) => (
                  <tr key={index}>
                    <td>{dato.medico}</td>
                    <td>{dato.fichaClinica}</td>
                    <td>{dato.tratamiento}</td>
                    <td>{dato.cara}</td>
                    <td>
                      {/* Ícono de borrado con manejador de eventos onClick */}
                      <FontAwesomeIcon
                        icon={faTrash}
                        onClick={() => this.handleEliminarFila(index)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }
}

export default HistorialClinico;