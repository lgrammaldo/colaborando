import React, { useState, useEffect } from 'react';
import turnoService from '../services/TurnoService';
import { useNavigate,useParams } from 'react-router-dom';
import PacienteService from '../services/PacienteService';
import OdontologoService from '../services/OdontologoService';
import Calendar from 'react-calendar';
import DisponibilidadHorariaServices from '../services/DisponibilidadHorariaService';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import Header from './Header';

const CrearTurno = () => {
    const [urgencia, setUrgencia] = useState(false);
    const [pacienteId, setPacienteId] = useState('');
    const [odontologoId, setOdontologoId] = useState('');
    const [pacientes, setPacientes] = useState([]);
    const [odontologos, setOdontologos] = useState([]);
    const [tratamientosDisponibles, setTratamientosDisponibles] = useState([]);
    const [fechaTurno, setFechaTurno] = useState(new Date()); // Estado para la fecha del turno
    const [horaTurno, setHoraTurno] = useState(''); // Estado para la hora del turno
    const [horarios, setHorarios] = useState([]);
    const navigate = useNavigate();
    const [diasDisponibles, setDiasDisponibles] = useState(new Set());
    const {id} = useParams('');

    useEffect(() => {
        // Obtén la lista de pacientes y odontólogos para mostrar en los select
        PacienteService.getPaciente().then((res) => {
            setPacientes(res.data);
        }).catch((error) => {
            console.error("Error al obtener pacientes:", error);
        });

        OdontologoService.getOdontologo().then((res) => {
            setOdontologos(res.data);
        }).catch((error) => {
            console.error("Error al obtener odontólogos:", error);
        });
    }, []);

    useEffect(() => {
        OdontologoService.getOdontologoEspecialidad().then((res) => {
            console.log(res.data)
            setTratamientosDisponibles(res.odontologo.especialidad);
        }).catch((error) => {
            console.error("Error al obtener tratamientos disponibles:", error);
        });
    }, []);

    useEffect(() => {
        turnoService.getTurnoById(id).then((res) => {
            const turno = res.data;
            setTratamientosDisponibles(turno.tratamiento);
            setOdontologoId(turno.odontologo.id);
            setFechaTurno(new Date(turno.fechaTurno));
            // Obtener la hora del turno en formato HH:mm
            const formattedHour = format(new Date(turno.fechaTurno), 'HH:mm', { locale: es });
            setHoraTurno(formattedHour);
            setUrgencia(turno.urgencia);
            setPacienteId(turno.paciente.id)
        });
    }, [id]);


    const formatHora = (fechaISO) => {
        if (!fechaISO) {
            return ''; // o algún valor predeterminado
        }

        const date = new Date(fechaISO);
        const formattedHour = format(date, 'HH:mm', { locale: es });
        return formattedHour;
    };

    const cargarDisponibilidad = (e) => {
        e.preventDefault();
        // Verificar que hay un odontólogo seleccionado
        if (!odontologoId) {
            alert("Por favor, selecciona un odontólogo antes de cargar la disponibilidad.");
            return;
        }

        // Hacer la solicitud para obtener los horarios del odontólogo seleccionado
        DisponibilidadHorariaServices.getDisponibilidadHorarios(odontologoId)
            .then(response => {
                const dias = response.data.map((horario) => horario.horario.diaSemana);
                setDiasDisponibles(new Set(dias));
                setHorarios(response.data);
            })
            .catch(error => {
                console.error("Error al obtener horarios:", error);
            });
    };

    const saveTurno = (e) => {
        e.preventDefault();
        if (!fechaTurno || !horaTurno) {
            alert("Por favor, selecciona fecha y hora del turno.");
            return;
        }

        const fechaHoraTurno = new Date(fechaTurno);
        const [hora, minutos] = horaTurno.split(':');
        fechaHoraTurno.setHours(Number(hora), Number(minutos));
        if (isNaN(fechaHoraTurno.getTime())) {
            alert("La fecha y hora del turno no son válidas.");
            return;
        }

       
        const fechaFormateada = new Date(fechaHoraTurno.getTime() - fechaHoraTurno.getTimezoneOffset() * 60000).toISOString();
    
        const turno = {
            urgencia,
            paciente: { id: pacienteId },
            odontologo: { id: odontologoId },
            tratamiento: odontologoId,  
            fechaTurno: fechaFormateada, // Convertir la fecha a formato ISO
        };
   
        turnoService.updateTurno(id, turno)
            .then(res => {
                navigate('/turnos');
                console.log("Turno:", turno);
                alert("El turno se ha actualizado correctamente.");
            })
            .catch(error => {
                // Manejar el error, por ejemplo, mostrar un mensaje al usuario
                alert("Hubo un error al actualizar el turno. Por favor, inténtalo de nuevo.");
            });
    }

    const cancelTurno = () => {
        navigate('/turnos');
    }

    const setDayToFilter = (date) => {
        const dayOfWeek = date.toLocaleDateString('es-ES', { weekday: 'long' }).toLowerCase();
        return !diasDisponibles.has(dayOfWeek);
    }

    return (
        <div>
            <Header />
            <div className='row'>
                <div className='card col-md-6 offset-md-3 offset-md-3'>
                    <h2 className="text-center">Editar Turno</h2>
                    
                    <div className="card-body">
                        <form>
                            <div className='form-group'>
                                <label>Tratamiento: </label>
                                <select name="tratamiento" className='form-control' value={odontologoId} onChange={(e) => setOdontologoId(e.target.value)}>
                                    <option value=""></option>
                                    {odontologos.map((odontologo) => (
                                        <option key={odontologo.id} value={odontologo.id}>{odontologo.especialidad}</option>
                                    ))}
                                </select>
                            </div>
                            <div className='form-group'>
                                <label>Odontólogo: </label>
                                <select name="odontologo" className='form-control' value={odontologoId} onChange={(e) => setOdontologoId(e.target.value)}>
                                    <option value="">Seleccionar Odontólogo</option>
                                    {odontologos.map((odontologo) => (
                                        <option key={odontologo.id} value={odontologo.id}>{odontologo.nombre} {odontologo.apellido}</option>
                                    ))}
                                </select>
                            </div>
                            <button className='btn btn-primary' onClick={cargarDisponibilidad}>Cargar Disponibilidad</button>

                            <div className='form-group'>
                                <label>Fecha y Hora del Turno: </label>
                                <div className="row">
                                    <div className='col'>
                                        {/* Calendario */}
                                        <Calendar
                                            onChange={setFechaTurno}
                                            value={fechaTurno}
                                            minDate={new Date()}
                                            locale="es-ES"
                                            showWeekNumbers={true}
                                            tileDisabled={({ date }) => {
                                               // const dayOfWeek = date.toLocaleDateString('es-ES', { weekday: 'long' }).toLowerCase();
                                              //  return !diasDisponibles.has(dayOfWeek);
                                                return setDayToFilter(date);
                                            }} />
                                    </div>
                                    <div className="col">
                                        {/* Desplegable con horas disponibles */}
                                        <select value={horaTurno} onChange={(e) => setHoraTurno(e.target.value)} className="form-control">
                                            <option value="">Seleccionar Hora</option>
                                            {horarios.map((horario) => (
                                                // Asegúrate de que horario tenga propiedades como "dia" y "hora" en tu modelo
                                                <option key={horario.id} value={formatHora(horario.horario.horaInicio)}>
                                                    {formatHora(horario.horario.horaInicio)}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div className='form-group'>
                                <label>Urgencia: </label>
                                <input type="checkbox" name="urgencia" className='form-control' checked={urgencia} onChange={(e) => setUrgencia(e.target.checked)} />
                            </div>
                            <div className='form-group'>
                                <label>Paciente: </label>
                                <select name="paciente" className='form-control' value={pacienteId} onChange={(e) => setPacienteId(e.target.value)} disabled>
                                    
                                    {pacientes.map((paciente) => (
                                        <option key={paciente.id} value={paciente.id}>{paciente.nombre} {paciente.apellido}</option>
                                    ))}
                                </select>
                            </div>
                            

                            <button className='btn btn-success' onClick={(e) => saveTurno(e)}>Guardar</button>
                            <button className='btn btn-danger' onClick={cancelTurno} style={{ marginLeft: "10px" }}>Cancelar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default CrearTurno;
