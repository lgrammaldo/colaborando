import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import odontologoService from '../services/OdontologoService';
import especialidadService from '../services/EspecialidadService';
import Header from './Header';


const ActualizarOdontologo = () => {
    const [nombre, setNombre] = useState('');
    const [apellido, setApellido] = useState('');
    const [email, setEmail] = useState('');
    const [telefono, setTelefono] = useState('');
    const {dni, setDNI} = useParams('');
    const [matricula, setMatricula] = useState('');
    const [especialidad, setEspecialidad] = useState('');
    const [especialidadesDisponibles, setEspecialidadesDisponibles] = useState([]);
    
    const navigate = useNavigate();

    useEffect(() => {
        // Aquí obtén las especialidades desde tu servicio y guárdalas en el estado
        especialidadService.getEspecialidad().then((res) => {
            console.log(res.data)
            setEspecialidadesDisponibles(res.data);
        }).catch((error) => {
            // Maneja los errores si es necesario
        });
    }, []);

    useEffect(() => {
        odontologoService.getOdontologoByDni(dni).then((res) => {
            const odontologo = res.data;
            setNombre(odontologo.nombre);
            setApellido(odontologo.apellido);
            setEmail(odontologo.email);
            setTelefono(odontologo.telefono);
            setMatricula(odontologo.matricula);
            setEspecialidad(odontologo.especialidad);
    
            // Revisa si odontologo.especialidadesDisponibles existe antes de establecerlo
            if (odontologo.especialidadesDisponibles) {
                setEspecialidadesDisponibles(odontologo.especialidadesDisponibles);
            }
        });
    }, [dni]);

    const saveOdontologo = (e) => {
        e.preventDefault();
        const odontologo = {
            nombre,
            apellido,
            email,
            telefono,
            dni,
            matricula,
            especialidad
        };

        console.log("odontologo => " + JSON.stringify(odontologo));
        odontologoService.updateOdontologo(dni, odontologo)
            .then(res => {
                navigate('/odontologo');
                alert("El odontologo se ha actualizado correctamente.");

            })
            .catch(error => {
                alert("Hubo un error al crear el turno. Por favor, inténtalo de nuevo.");
            });
    }

    const cancelOdontologo = () => {
        navigate('/odontologo');
    }

    return (
        <div>
            <Header />
            <div className='row'>
                <div className='card col-md-6 offset-md-3 offset-md-3'>
                    <h2 className="text-center">Editar Odontólogo</h2>
                    <div className="card-body">
                        <form>
                            <div className='form-group'>
                                <label>Nombre: </label>
                                <input type="text" name="nombre" className='from-control' value={nombre} onChange={(e) => setNombre(e.target.value)} />
                            </div>
                            <div className='form-group'>
                                <label>Apellido: </label>
                                <input type="text" name="nombre" className='from-control' value={apellido} onChange={(e) => setApellido(e.target.value)} />
                            </div>
                            <div className='form-group'>
                                <label>DNI: </label>
                                <input type="text" name="dni" className='from-control' value={dni} onChange={(e) => setDNI(e.target.value)} />
                            </div>
                            <div className='form-group'>
                                <label>Correo: </label>
                                <input type="text" name="email" className='from-control' value={email} onChange={(e) => setEmail(e.target.value)} />
                            </div>
                            <div className='form-group'>
                                <label>Teléfono/Celular: </label>
                                <input type="text" name="telefono" className='from-control' value={telefono} onChange={(e) => setTelefono(e.target.value)} />
                            </div>
                            <div className='form-group'>
                                <label>Matricula </label>
                                <input type="text" name="alergias" className='from-control' value={matricula} onChange={(e) => setMatricula(e.target.value)} />
                            </div>
                            <div className='form-group'>
                                <label>Especialidades: </label>
                                <select name="especialidad" className='form-control' value={especialidad} onChange={(e) => setEspecialidad(e.target.value)}>
                                    <option value="">Seleccionar Especialidad</option>
                                    {especialidadesDisponibles.map((esp, index) => (
                                        <option key={index} value={esp}>{esp}</option>
                                    ))}
                                </select>
                            </div>
                            <button className='btn btn-success' onClick={saveOdontologo}>Guardar</button>
                            <button className='btn btn-danger' onClick={cancelOdontologo} style={{ marginLeft: "10px" }}>Cancelar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ActualizarOdontologo;
