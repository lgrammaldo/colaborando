import React, { useState } from 'react';
import NavBar from '../principal/NavBar';
import logo from '../imagenes/logologin.png';
import './Login.css';
import LoginService from '../services/LoginService';
import { useNavigate } from 'react-router-dom';

const Login = ({ history }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const validateForm = () => {
    return username.trim() !== '' && password.trim() !== '';
  };

  const navigate = useNavigate();
  

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    if (validateForm()) {
      try {
        const response = await LoginService.authenticateUser({ username, password });
        localStorage.setItem('token', response.data?.token);
        localStorage.setItem('rol', response.data?.rol);
        navigate('/turnos');
      } catch (error) {
        const resMessage = (error.response && error.response.data && error.response.data.message) || error.message || error.toString();
        setLoading(false);
        setMessage(resMessage);
      }
    } else {
      setLoading(false);
      setMessage('¡Completa todos los campos!');
    }
  };

  return (
    <div>
      <NavBar />
      <div className="container h-100">
        <div className="row h-100 justify-content-center align-items-center">
          <div className="col-md-6">
            <div className="card">
              <div className="card-body">
                <h1 className="text-center mb-4">Bienvenido</h1>
                <p>Iniciar sesión</p>
                <img src={logo} alt="Logo" className="mb-4" />
                <form onSubmit={handleLogin}>
                  <div className="mb-3">
                    <input
                      type="text"
                      className="form-control"
                      id="username"
                      name="username"
                      placeholder="Username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <input
                      type="password"
                      className="form-control"
                      id="password"
                      name="password"
                      placeholder="Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                  <div className="text-center">
                    <button
                      type="submit"
                      className="btn btn-primary"
                      disabled={loading}
                    >
                      {loading && (
                        <span className="spinner-border spinner-border-sm"></span>
                      )}
                      Ingresar
                    </button>
                  </div>
                </form>
                {message && (
                  <div className="form-group mt-3">
                    <div className="alert alert-danger" role="alert">
                      {message}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
