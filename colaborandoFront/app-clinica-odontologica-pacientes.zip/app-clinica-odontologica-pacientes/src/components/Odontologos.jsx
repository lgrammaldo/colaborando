import React, { useState, useEffect } from 'react';
import Header from './Header';
import OdontologoService from '../services/OdontologoService';
import { useNavigate } from 'react-router-dom';

function Odontologo() {
    const [odontologos, setOdontologos] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        OdontologoService.getOdontologo().then((res) => {
            setOdontologos(res.data);
        });
    }, []);

    const addOdontologo = () => {
        navigate('/crear-odontologo');
    }

    const editOdontologo = (dni) => {
        navigate(`/actualizar-odontologo/${dni}`);
    }

    const deleteOdontologo = (dni) => {
        OdontologoService.deleteOdontologo(dni).then((res) => {
            setOdontologos((prevOdontologos) => prevOdontologos.filter((odontologo) => odontologo.dni !== dni));
        });
    };


    return (
        <div >
            <Header />
            <div className='container'>
                <h2 className='text-center'>Lista de Odontólogos</h2>
                <div className='row'>
                    <button className='btn btn-primary' onClick={addOdontologo}>Agregar Odontólogo</button>
                </div>
                <div className="row">
                    <table className="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>DNI</th>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Correo</th>
                                <th>Teléfono</th>
                                <th>Matricula</th>
                                <th>Especialidad</th>
                                <th>Opciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            {odontologos.map(odontologo => (
                                <tr key={odontologo.id}>
                                    <td>{odontologo.dni}</td>
                                    <td>{odontologo.nombre}</td>
                                    <td>{odontologo.apellido}</td>
                                    <td>{odontologo.email}</td>
                                    <td>{odontologo.telefono}</td>
                                    <td>{odontologo.matricula}</td>
                                    <td>
                                        {odontologo.especialidad}
                                    </td>

                                    <td>
                                        <button onClick={() => editOdontologo(odontologo.dni)} className='btn btn-info'>Actualizar</button>
                                        <button onClick={() => deleteOdontologo(odontologo.dni)} className='btn btn-danger' style={{ marginLeft: "10px" }}>Eliminar</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}

export default Odontologo;
