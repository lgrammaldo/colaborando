
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Turnos from './components/Turnos';
import Pacientes from './components/Pacientes';
import HistorialClinico from './components/HistorialClinico';
import CrearPaciente from './components/CrearPaciente';
import ActualizarPaciente from './components/ActualizarPaciente';
import ActualizarOdontologo from './components/ActualizarOdontologo';
import DetallePaciente from './components/DetallePaciente';
import Odontologos from './components/Odontologos';
import CrearOdontologo from './components/CrearOdontologo';
import CrearTurno from './components/CrearTurno';
import Login from './components/Login';
import RegistrarUsuario from './components/RegistrarUsuario';
import ActualizarTurno from './components/ActualizarTurno';
import CrearHistorialClinico from './components/CrearHistorialClinico'

function App() {

  return (
    <div className="App">
      <Router>
        <div>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/registro" element={<RegistrarUsuario />} />
              <Route path="/turnos" element={<Turnos />} />
              <Route path="/login" element={<Login />} />
              <Route path="/paciente" element={<Pacientes />} />
              <Route path="/crear-turnos" element={<CrearTurno />} />
              <Route path="/actualizar-turno/:id" element={<ActualizarTurno />} />
              <Route path="/crear-paciente" element={<CrearPaciente />} />
              <Route path="/actualizar-paciente/:dni" element={<ActualizarPaciente />} />
              <Route path="/detalle-paciente/:dni" element={<DetallePaciente />} />
              <Route path="/historial-clinico/:dni" element={<HistorialClinico />} />
              <Route path="/odontologo" element={<Odontologos />} />
              <Route path="/crear-odontologo" element={<CrearOdontologo />} />
              <Route path="/agregar-historial/:dni" element={<CrearHistorialClinico />} />
              <Route path="/actualizar-odontologo/:dni" element={<ActualizarOdontologo />} />
              {/* Asegúrate de tener una ruta para las demás opciones */}
              <Route path="*" element={<Navigate to="/login" />} />
          </Routes>
        </div>
      </Router>
    </div>
  );
}

export default App;
