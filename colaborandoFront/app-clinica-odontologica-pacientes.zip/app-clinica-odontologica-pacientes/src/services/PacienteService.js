import axios from 'axios';

const PACIENTE_API_BASE_URL = "http://localhost:8080/sonrisadental/pacientes";
const token = localStorage.getItem("token");

class PacienteService { 
    getPaciente(){
        return axios.get(PACIENTE_API_BASE_URL, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
    }

    createPaciente(paciente){
        return axios.post(PACIENTE_API_BASE_URL, paciente, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          })
    }

    getPacienteByDni(pacienteDni){
        return axios.get(PACIENTE_API_BASE_URL + '/' + pacienteDni, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          })
    }

    updatePaciente(pacienteDni, paciente){
        return axios.put(PACIENTE_API_BASE_URL + '/' + pacienteDni, paciente, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
    }

    deletePaciente(pacienteDni){
        return axios.delete(PACIENTE_API_BASE_URL + '/' + pacienteDni, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          })
    }

    buscarPacientesPorNombre(nombre, pagina, tamano) {
        return axios.get(`${PACIENTE_API_BASE_URL}/buscar?nombre=${nombre}&pagina=${pagina}&tamano=${tamano}`, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          })
            .then(response => response.data);
    }

    getPacientesPaginados(pagina, tamano) {
        return axios.get(`${PACIENTE_API_BASE_URL}?pagina=${pagina}&tamano=${tamano}`, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          })
          .then(response => response.data);
      }
    
}

const pacienteService = new PacienteService();

export default pacienteService;