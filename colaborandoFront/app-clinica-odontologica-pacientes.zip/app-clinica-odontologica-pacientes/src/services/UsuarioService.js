import axios from 'axios';
import authHeader from './AuthHeaderService';

const USUARIO_API_BASE_URL = "http://localhost:8080/sonrisadental/test/";

class UsuarioService {
    getPublicContect(){
        return axios.get(USUARIO_API_BASE_URL + 'all');
    }

    getUserBoard(){
        return axios.get(USUARIO_API_BASE_URL + 'user', {headers: authHeader() });
    }

    getRecepcionistaBoard(){
        return axios.get(USUARIO_API_BASE_URL + 'recepcion', {headers: authHeader() });
    }

    getOdontologoBoard(){
        return axios.get(USUARIO_API_BASE_URL + 'odontologo', {headers: authHeader() });
    }
}

const usuarioService = new UsuarioService();

export default usuarioService;