import axios from 'axios';

const HISTORIAL_API_BASE_URL = "http://localhost:8080/sonrisadental/historialClinico";
const token = localStorage.getItem("token");

class HistorialClinicoService{
    getHistorialClinico(){
        return axios.get(HISTORIAL_API_BASE_URL, {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
    }
  
    getHistorialClinicoByDNI(dni){
      return axios.get(HISTORIAL_API_BASE_URL, + '/' + dni, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
  }

    createHistorialClinico(nuevoTratamiento) {
      return axios.post(HISTORIAL_API_BASE_URL, nuevoTratamiento, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
    }

    getHistorialClinicoByPacienteDNI(pacienteDNI) {
      return axios.get(HISTORIAL_API_BASE_URL + '/' + pacienteDNI, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
    }

    updateHistorialClinico(id, tratamientoData) {
      return axios.put(HISTORIAL_API_BASE_URL + '/' + id, tratamientoData, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
    }
  
    deleteHistorialClinico(tratamientoId) {
      return axios.delete(HISTORIAL_API_BASE_URL + '/' + tratamientoId, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
    }

}

const historialClinicoService = new HistorialClinicoService();
export default historialClinicoService;

