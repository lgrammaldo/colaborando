import axios from 'axios';

const ESPECIALIDAD_API_BASE_URL = "http://localhost:8080/sonrisadental/especialidades";
const token = localStorage.getItem("token");

class EspecialidadServices{
    getEspecialidad(){
        return axios.get(ESPECIALIDAD_API_BASE_URL, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
    }

}

const especialidadService = new EspecialidadServices();
export default especialidadService;

