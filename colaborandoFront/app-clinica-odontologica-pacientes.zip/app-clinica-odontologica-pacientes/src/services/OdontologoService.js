import axios from 'axios';

const ODONTOLOGO_API_BASE_URL = "http://localhost:8080/sonrisadental/odontologos";
const token = localStorage.getItem("token");

class OdontologoService { 
    getOdontologo(){
        return axios.get(ODONTOLOGO_API_BASE_URL, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
    }

    createOdontologo(odontologo){
        return axios.post(ODONTOLOGO_API_BASE_URL, odontologo, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          })
    }

    getOdontologoByDni(odontologoDni){
        return axios.get(ODONTOLOGO_API_BASE_URL + '/' + odontologoDni, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          })
    }
    getOdontologoEspecialidad(odontologoDni){
        return axios.get(ODONTOLOGO_API_BASE_URL + '/' + odontologoDni, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          })
        .then(response => {
            const {odontologo, especialidad } = response.data;
            return { odontologo, especialidad };
        })
    }

    
    updateOdontologo(odontologoDni, odontologo){
        return axios.put(ODONTOLOGO_API_BASE_URL + '/' + odontologoDni, odontologo, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
    }

    deleteOdontologo(odontologoDni){
        return axios.delete(ODONTOLOGO_API_BASE_URL + '/' + odontologoDni, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          })
    }
}

const odontologoService = new OdontologoService();

export default odontologoService;