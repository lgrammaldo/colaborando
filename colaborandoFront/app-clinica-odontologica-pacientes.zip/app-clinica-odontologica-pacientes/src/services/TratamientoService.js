import axios from 'axios';

const TRATAMIENTO_API_BASE_URL = "http://localhost:8080/sonrisadental/tratamientos";
const token = localStorage.getItem("token");

class TratamientoService{
    getTratamiento(){
        return axios.get(TRATAMIENTO_API_BASE_URL, {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
    }

}

const tratamientoService = new TratamientoService();
export default tratamientoService;

