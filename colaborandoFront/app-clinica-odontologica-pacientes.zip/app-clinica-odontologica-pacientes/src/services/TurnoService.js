import axios from 'axios';

const TURNO_API_BASE_URL = "http://localhost:8080/sonrisadental/turnos";
const token = localStorage.getItem("token");

class TurnoService { 
    getTurno(){
        return axios.get(TURNO_API_BASE_URL, {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
    }

    createTurno(turno){
        return axios.post(TURNO_API_BASE_URL, turno, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
          })
    }

    getTurnoById(turnoId){
      return axios.get(TURNO_API_BASE_URL + '/' + turnoId,{
        headers: {
          Authorization: `Bearer ${token}`
        }
      })
    }

    updateTurno(tunoId, turno){
        return axios.put(TURNO_API_BASE_URL + '/' + tunoId, turno, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
          });
    }

    deleteTurno(turnoId){
        return axios.delete(TURNO_API_BASE_URL + '/' + turnoId, {
          headers: {
            Authorization: `Bearer ${token}`,
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': "GET, OPTIONS, POST, PUT"
          },
          mode: "no-cors",
          })
    }
    
}

const turnoService = new TurnoService();

export default turnoService;