import axios from '../config/axiosConfig';

const DISPONIBILIDAD_API_BASE_URL = "http://localhost:8080/sonrisadental/disponibilidad-horaria";

class DisponibilidadHorariaServices{
    getDisponibilidadHorarios(odontologoId){
        return axios.get(DISPONIBILIDAD_API_BASE_URL + '/' + odontologoId);
    }   
    
}

const turnosDisponiblesService = new DisponibilidadHorariaServices();
export default turnosDisponiblesService;

